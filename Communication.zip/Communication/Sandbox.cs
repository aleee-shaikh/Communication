﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Communication
{
    public class Sandbox
    {
        void SendEmail()
        {
            Communication.Email.sendEmail("fromEmail@test.com","ToEmail1@test.com;ToEmail2@test.com","Test Subject","Test Message");
            Communication.SMS.Twilio_SMS.SendSMS("121121", "test sms message", "132222332", "332223232323");
            Communication.SMS.TheTexting_SMS.SendSMS("54454544545", "test sms message");
        }
    }
}