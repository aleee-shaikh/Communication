﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace Communication.Communication
{
    namespace SMS
    {
        #region "TWILIO"
        public class Twilio_SMS
        {
            public static string SendSMS(string authToken, string message, string fromNumber, string toNumber)
            {
                if (message.Trim().Length==0)
                {
                    return Setting.getSetting("SMSResponse_MESSAGE_TEXT_EMPTY", "Message can not be empty");
                }
                else if (message.Length > 160)
                {
                    return Setting.getSetting("SMSResponse_MESSAGE_TEXT_EXCEED", "Message can not be more than 160 characters");
                }
                else if (fromNumber.Trim() == "")
                {
                    return Setting.getSetting("SMSResponse_INVALID_FROM_NUMBER", "To number is missing");
                }
                else if (toNumber.Trim() == "")
                {
                    return Setting.getSetting("SMSResponse_INVALID_TO_NUMBER", "From number is missing");
                }

                string accountSid= Setting.getSetting("TWILIO_SMS_ACCOUNT_ID", "XXXXXXXXXXXXXXXXXX");
                //TwilioClient.Init(accountSid, authToken);

                //var messageObj = MessageResource.Create(
                //    body: message,
                //    from: new Twilio.Types.PhoneNumber(fromNumber),
                //    to: new Twilio.Types.PhoneNumber(toNumber)
                //);

                return "SMS Sent Successfully";
            }
        }
        #endregion

        #region "TheTexting"
        public class TheTexting_SMS
        {
            public static string SendSMS(string toNumber, string message)
            {
                if (message.Trim().Length == 0)
                {
                    return Setting.getSetting("SMSResponse_MESSAGE_TEXT_EMPTY", "Message can not be empty");
                }
                else if (message.Length > 160)
                {
                    return Setting.getSetting("SMSResponse_MESSAGE_TEXT_EXCEED", "Message can not be more than 160 characters");
                }
                else if (toNumber.Trim() == "")
                {
                    return Setting.getSetting("SMSResponse_INVALID_TO_NUMBER", "From number is missing");
                }

                string API_KEY = Setting.getSetting("TheTexting_SMS_API_KEY", "XXXXXXXXXXXXXXXXXX");
                string API_SECRET = Setting.getSetting("TheTexting_SMS_API_SECERET", "XXXXXXXXXXXXXXXXXX"); ;
                double TO = Convert.ToDouble(toNumber);
                string Message = message;
                string sURL;
                sURL = "https://www.thetexting.com/rest/sms/json/message/send?api_key=" + API_KEY + "&api_secret=" + API_SECRET + "&to=" + TO + "&text=" + Message;
                try
                {
                    using (WebClient client = new WebClient())
                    {

                        string s = client.DownloadString(sURL);

                        var responseObject = Newtonsoft.Json.JsonConvert.DeserializeObject<RootObject>(s);
                        int n = responseObject.Status;
                        if (n == 3)
                        {
                            return "Message does not Send Successfully due to invalid credentials !";
                        }
                        else
                        {
                            return "<script>alert('Message Send Successfully !";
                        }
                    }
                }
                catch (Exception ex)
                {
                    return ex.ToString();
                }
                return "Sent Successfully";
            }

        }

        public class Response
        {
            public string message_id { get; set; }
            public int message_count { get; set; }
            public double price { get; set; }
        }

        public class RootObject
        {
            public Response Response { get; set; }
            public string ErrorMessage { get; set; }
            public int Status { get; set; }
        }
        #endregion
    }
}