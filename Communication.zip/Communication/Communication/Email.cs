﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Web;

namespace Communication.Communication
{
    public class Email
    {
        public static string sendEmail(string fromEmail, string toEmail, string subject, string emailMessage,
            string ccEmail = "", string bccEmail = "", string attachedFiles = "", string emailTemplateFile = "",
            string replaceWith = "")
        {
            string SMTPServer = Setting.getSetting("SMTPServer", "mail.test.com");
            string SMTPPassword = Setting.getSetting("MailPassword", "password123");
            string response = "";

            #region "Email Validation"
            if (fromEmail.Trim() == "" || IsValidEmail(fromEmail.Trim()) == false)
            {
                response = Setting.getSetting("EmailResponse_InvalidFromEmailAddress", "Invalid/Missing From email address");
                return response;
            }
            else if (toEmail.Trim() == "" || IsValidEmail(toEmail.Trim()) == false)
            {
                response = Setting.getSetting("EmailResponse_InvalidToEmailAddress", "Invalid/Missing To email address");
                return response;
            }
            else if (ccEmail.Trim() != "" || IsValidEmail(ccEmail.Trim()) == false)
            {
                response = Setting.getSetting("EmailResponse_InvalidCCEmailAddress", "Invalid/Missing CC email address");
                return response;
            }
            else if (bccEmail.Trim() != "" || IsValidEmail(bccEmail.Trim()) == false)
            {
                response = Setting.getSetting("EmailResponse_InvalidBCCEmailAddress", "Invalid/Missing BCC email address");
                return response;
            }
            else if (emailTemplateFile.Trim() != "" && System.IO.File.Exists(emailTemplateFile) == false)//if email template file is missing
            {
                response = Setting.getSetting("EmailResponse_EmailTemplateFileMissing", "Email Template file is missing");
                return response;
            }
            #endregion

            #region "Preparing email body"
            string message;
            if (emailTemplateFile == "" && emailMessage != "")//if plain email to send
                message = emailMessage;
            else //if template is to used for email body
            {
                message = GetEmailTemplate(emailTemplateFile);
            }
            #endregion

            #region "Replace codes in email body with provided data"
            string[] ReplacingWordsAry = replaceWith.Split('¤'); // 'Alt+4
            foreach (var rword in ReplacingWordsAry)
            {
                string[] WordAry = rword.Split('♦'); // 'Alt+R
                if (WordAry.Length > 1)
                {
                    string WordToReplace = WordAry[0];
                    string WordReplaceWith = WordAry[1];
                    message = message.Replace(WordToReplace, WordReplaceWith);
                    subject = subject.Replace(WordToReplace, WordReplaceWith);
                }
            }
            #endregion 

            #region"preparing email object"
            MailMessage mm = new MailMessage();
            if ((toEmail.IndexOf(";") >= 0))//if there are multiple to email like email1@test.com;email2@test.com;.....
            {
                mm = new MailMessage();
                mm.From = new MailAddress(fromEmail);
                string[] emls = toEmail.Split(';');
                for (int i = 0; i <= emls.Length - 1; i++)
                {
                    if ((emls[i].Trim() != ""))
                        mm.To.Add(emls[i]);
                }
            }
            else
            {
                mm = new MailMessage(Setting.getSetting("FromEmailAddress", "info@test.com"), toEmail);
            }

            if (ccEmail != "")
            {
                if ((ccEmail.IndexOf(";") >= 0))
                {
                    string[] CCemls = ccEmail.Split(';');
                    for (int i = 0; i <= CCemls.Length - 1; i++)
                        mm.CC.Add(CCemls[i]);
                }
            }
            else if (ccEmail.Trim() != "")
            {
                mm.CC.Add(ccEmail);
            }


            if (bccEmail != "")
            {
                if ((bccEmail.IndexOf(";") >= 0))
                {
                    string[] BCCemls = bccEmail.Split(';');
                    for (int i = 0; i <= BCCemls.Length - 1; i++)
                        mm.Bcc.Add(BCCemls[i]);
                }
            }
            else if (ccEmail.Trim() != "")
            {
                mm.Bcc.Add(bccEmail);
            }
            #endregion

            #region "Email Attachment"
            FileStream fs;
            if (attachedFiles != "")
            {
                string FilePath;
                string[] AttachedFilesList;
                AttachedFilesList = attachedFiles.Split(',');
                foreach (string File in AttachedFilesList)
                {
                    FilePath = HttpContext.Current.Server.MapPath(File);
                    fs = new System.IO.FileStream(FilePath, System.IO.FileMode.Open);
                    mm.Attachments.Add(new Attachment(fs, FilePath));
                }
            }
            #endregion

            #region "Sending Email"
            SmtpClient smtp = new SmtpClient(SMTPServer, Convert.ToInt32(Setting.getSetting("SMTPPort", "25")));
            mm.Subject = subject;
            mm.Body = message;
            mm.IsBodyHtml = true;
            smtp.Credentials = new System.Net.NetworkCredential(Setting.getSetting("HostingMailAccount", "email@yourdomain.com"), SMTPPassword);
            try
            {
                smtp.Timeout = Convert.ToInt32(Setting.getSetting("MailTimeout", "200000"));
                smtp.Send(mm);
                return Setting.getSetting("EmailResponse_Success", "Email Sent Successfully");
            }
            catch (Exception ex)
            {
                return Setting.getSetting("EmailResponse_Fail", "Email was not sent" + Environment.NewLine + ex.Message.ToString());
            }
            finally
            {

            }
            #endregion
        }

        private static string GetEmailTemplate(string TemplateFile)
        {
            string TemplateHTML = "";
            try
            {
                TemplateHTML = System.IO.File.ReadAllText(System.Web.Hosting.HostingEnvironment.MapPath("/App/EmailTemplates/" + TemplateFile + ".tmpl.htm"));
            }
            catch (Exception ex)
            {
            }

            return TemplateHTML;
        }

        public static bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }
    }
}