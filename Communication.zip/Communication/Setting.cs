﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

public class Setting
{
    public static string getSetting(string key, string defaultValue)
    {
        string settingValue = "";
        if (ConfigurationManager.AppSettings[key] != null)
        {
            settingValue = ConfigurationManager.AppSettings[key].ToString();
        }
        else
        {
            settingValue = defaultValue;
        }
        return settingValue;
    }

}